-- if the table exists, delete it
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `posts`;
DROP TABLE IF EXISTS `comments`;

-- create a new table
CREATE TABLE users(
	username varchar(50) PRIMARY KEY,
	password varchar(100) NOT NULL,
	enabled int
);

CREATE TABLE `posts`(
	posts_id int NOT NULL AUTO_INCREMENT PRIMARY KEY,
	message text,
	time_stamp TIMESTAMP,
	`owner` varchar(50),
	FOREIGN KEY (`owner`) REFERENCES `users`(`username`) ON DELETE CASCADE
);

CREATE TABLE `comments`(
	comments_id int NOT NULL AUTO_INCREMENT PRIMARY KEY,
	message text,
	time_stamp TIMESTAMP,
	posts_id int,
	`owner` varchar(50),
	FOREIGN KEY (`owner`) REFERENCES `users`(`username`) ON DELETE CASCADE,
	FOREIGN KEY (posts_id) REFERENCES posts(posts_id) ON DELETE CASCADE
);

-- insert data to the table users
LOCK TABLES `users` WRITE;
INSERT INTO `users` VALUES ('admin',password('team13Admin'),1);
UNLOCK TABLES;
SET FOREIGN_KEY_CHECKS=1;