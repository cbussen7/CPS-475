<?php
	$mysqli = new mysqli('localhost','admin','team13Admin','secadteam13');
	if($mysqli->connect_errno){
		printf("Database connection failed: %s\n", $mysqli->connect_error);
		exit();
	}

	function changepassword($username, $newpassword) {
		global $mysqli;
		$prepared_sql = "UPDATE users SET password=password(?) WHERE username= ?;";
		echo "DEBUG>prepared_sql= $prepared_sql\n";
		if(!$stmt = $mysqli->prepare($prepared_sql)) return FALSE;
		$stmt->bind_param("ss", $newpassword,$username);
		if(!$stmt->execute()) return FALSE;
		return TRUE;
  	}


  	function createpost($owner, $message) {
  		global $mysqli;
        $time_stamp = date('Y-m-d H:i:s');
		$prepared_sql = "INSERT INTO posts(message, time_stamp, owner) VALUES (?, ?, ?);";
		if(!$stmt = $mysqli->prepare($prepared_sql)) return FALSE;
		$stmt->bind_param("sss", $message, $time_stamp, $owner);
		if(!$stmt->execute()) return FALSE;
		return TRUE;
  	}
?>
