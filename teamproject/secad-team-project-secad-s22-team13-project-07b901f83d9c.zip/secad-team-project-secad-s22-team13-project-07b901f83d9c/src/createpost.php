<?php
	require "session_auth.php";
	require "database.php";
	$username=$_SESSION["username"];
	$userpost=$_REQUEST["userpost"];

	if (isset($username) AND isset($userpost)) {
		if (!createpost($username, $userpost)) {
			echo "<script>alert('Error: The post was not stored in the database.');</script>";
		}
	} else {
        echo "<script>alert('Error: cannot find user or post.');</script>";
		exit();
	}
    header("Refresh:0; url=index.php");
?>