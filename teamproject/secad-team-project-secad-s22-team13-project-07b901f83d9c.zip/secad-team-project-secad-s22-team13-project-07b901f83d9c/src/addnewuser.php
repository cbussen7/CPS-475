<?php
	require "database.php";
	$username = $_POST["username"];
	$password = $_POST["password"];

	function addnewuser($username, $password) {
		global $mysqli;
		$prepared_sql = "INSERT INTO users SET username=?,password=PASSWORD(?);";
		echo "DEBUG>prepared_sql= $prepared_sql\n";
		if(!$stmt = $mysqli->prepare($prepared_sql)) return FALSE;
		$stmt->bind_param("ss", $username, $password);
		if(!$stmt->execute()) return FALSE;
		return TRUE;
	}

	if(isset($username) AND isset($password)){
	  echo "DEBUG:addnewuser.php->Got: username=$username;password=$password\n<br>";
	  if(addnewuser($username,$password)){
	    echo "<h4>The new user has been created.</h4>";
	  }else{
	    echo "<h4>Error: Cannot create the user.</h4>";
	  }
	}else{
	  echo "No provided username/password to create.";
	  exit();
	}
?>
<a href="index.php">Home</a> | <a href="logout.php">Logout</a> | <a href="changepasswordform.php">Change Password</a>