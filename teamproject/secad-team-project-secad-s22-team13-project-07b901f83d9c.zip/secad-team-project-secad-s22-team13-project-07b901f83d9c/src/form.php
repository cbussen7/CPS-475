<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Login page - SecAD</title>
</head>
<body>
      	<h1>Team Project, SecAD</h1>
      	<h2>Team 13: Christopher Bussen and Joe Durham</h2>

<?php
  //some code here
  echo "Current time: " . date("Y-m-d h:i:sa")
?>
          <form action="index.php" method="POST" class="form login">
                Username:<input type="text" class="text_field" name="username" /> <br>
                Password: <input type="password" class="text_field" name="password" /> <br>
                <button class="button" type="submit">
                  Login
                </button>
          </form>

          <form action="registrationform.php" method="POST" class="new user">
            <button class="button" type="submit">
              Create New User
            </button>
          </form>

</body>
</html>

