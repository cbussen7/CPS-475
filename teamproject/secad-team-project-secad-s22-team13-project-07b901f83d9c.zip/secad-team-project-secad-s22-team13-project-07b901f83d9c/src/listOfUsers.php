<?php
  require "session_auth.php";
  require "database.php";
  $nocsrftoken = $_POST["nocsrftoken"];

?>

<html>

 <table id="table" style="width:40%" align="center">
     <tr>
          <th><h2><b>List of Registered Users, for Admin only</b></h2></th>
     </tr>
     <tr>

     <?php 

            $prepared_sql = "select username from users;";
            if(!$stmt = $mysqli->prepare($prepared_sql)){
                return FALSE;
            }
            if(!$stmt->execute()) return false;
            $username = NULL;
            if(!$stmt->bind_result($username)) echo "Binding failed";

            while($stmt->fetch()){
            ?>  
                 <td><?php echo htmlentities($username)?></td>
        </tr>
        <?php
            }
        ?>

        </table>
        <a href="index.php">Home</a>
        </html>