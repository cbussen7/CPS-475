<?php
    require "session_auth.php";
    if(isset($_GET["post_id"])){
        $post_id =  $_GET["post_id"];
    }
?>

<html>
<body>
    <div id="commentform" style="display:inline;">
        <form action="createcomment.php?post_id=<?php echo htmlentities($post_id); ?>" method="POST" style="display: inline;">
            <textarea rows="1" cols="30" name="usercomment"></textarea>
            <button class="button" type="submit">
             Comment 
            </button>
        </form>
    </div>

    <script>
        function showForm(){
            var ele = document.getElementById("commentform");
            if(ele.style.display === "none"){
                ele.style.display = "block";
            }else{
                ele.style.display = "none";
            }
        }
    </script>
    </body>
    </html>