<?php
	require "session_auth.php";
	require "database.php";
	$username = $_SESSION["username"];
	$checkedlist = $_POST["checkedlist"];

	function userAbilities($checklist){
		global $mysqli;
		$prepared_sql = "UPDATE users SET enabled=0 WHERE username != 'admin';";
    	if(!$stmt = $mysqli->prepare($prepared_sql)) return FALSE;
    	if(!$stmt->execute()) return FALSE;

    	foreach ($checklist as $check => $user) {
    		$prepared_sql = "UPDATE users SET enabled=1 WHERE username=?;";
    		if(!$stmt = $mysqli->prepare($prepared_sql)) return FALSE;
    		$stmt->bind_param('s', $user);
    		if(!$stmt->execute()) return FALSE;
    	}
    	return TRUE;
	}

	if (isset($username) AND isset($checkedlist)) {
		if (userAbilities($checkedlist)) {
			echo "<script>alert('The new enable/disable setting has been set.');</script>";
		} else {
			echo "<script>alert('Error: Cannot enable/disable the user');</script>";
		}
	} else {
		echo "<script>alert('You cannot disable every user from the website! Try again');</script>";
	}
	header("Refresh:0; url=index.php");
>