<?php
    require "session_auth.php";
?>
<html>
<body>
    <form action="createpost.php" method="POST" style="display:inline" >
        <b>What do you want to post?</b> </br>
        <textarea rows="5" cols="50" name="userpost"></textarea>
        <button class="button" type="submit">
          Post
        </button>
    </form>
</body>
</html>
</br>